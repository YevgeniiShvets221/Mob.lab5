package com.example.lab5_3;

import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import java.util.Objects;

    //class for notice about switched Airplane mode

public class NotificationForAirplaneMode extends DialogFragment {
    boolean AirplaneModeSwitched;

    public NotificationForAirplaneMode(boolean AirplaneModeOn) {
        this.AirplaneModeSwitched = AirplaneModeOn; // запуск режима в самолете
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(Objects.requireNonNull(getActivity()));
        builder.setTitle("Режим в самолете");
        if(AirplaneModeSwitched) {
            builder.setMessage("Включен:)");//включение режима
        }
        else {
            builder.setMessage("Отключен:)");// в обратном случае отключение
             }
              builder.setPositiveButton("Подтверждение", null);// подтв. режима
        return builder.create();
    }
}