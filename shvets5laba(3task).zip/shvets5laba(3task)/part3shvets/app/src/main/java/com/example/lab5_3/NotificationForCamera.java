package com.example.lab5_3;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

   //class for notice about launched Camera

public class NotificationForCamera extends DialogFragment {
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());// сообщение о запуске камеры
        builder.setTitle("Камера");// название
        builder.setMessage("Камера включена$");
        builder.setPositiveButton("Подтверждение", null);// подтв. работы камеры
        return builder.create();
    }
}